import 'package:flutter/material.dart';
import 'package:flutter_gemini/flutter_gemini.dart';

class DoaSearchScreen extends StatefulWidget {
  const DoaSearchScreen({super.key});

  @override
  _DoaSearchScreenState createState() => _DoaSearchScreenState();
}

class _DoaSearchScreenState extends State<DoaSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchResult = '';
  bool _isLoading = false;
  final Gemini gemini = Gemini.instance;

  Future<void> _searchDoa() async {
    setState(() {
      _searchResult = 'Mencari doa untuk: ${_searchController.text}...\n';
    });

    final instruction = '''
System intruction:
"saya sedang membuat sebuah aplikasi doa-doa islami menggunakan flutter dan bisa mencari doa yang saya integrasikan dengan ai(anda), setiap doa yang dicari anda hanya tinggal mencari doanya dan menjawab hanya dengan struktur kalimat berikut:
[Nama doa yang dicari]
[Bacaan doa yang dicari]
[Bacaan Latin doa yang dicari]
Artinya: [Arti doa yang dicari]
"
User: "${_searchController.text}"
''';

    try {
 setState(() {
 _isLoading = true;
      });
 gemini.prompt(parts: [
        Part.text(instruction),
 ]).then((value) {
 if (value != null && value.output != null) {
          setState(() {
 _searchResult = value.output!;
          });
 } else {
          setState(() {
 _searchResult = 'Tidak ada hasil ditemukan.';
          });
 }
      }).catchError((e) {
 setState(() {
 _searchResult = 'Terjadi kesalahan: $e';
 });
      }).whenComplete(() {
 setState(() {
 _isLoading = false;
 });
      });

    } catch (e) {
      setState(() {
        _searchResult = 'Terjadi kesalahan saat mencari doa: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cari Doa dengan AI'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Cari doa (misal: doa sebelum makan)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _isLoading ? null : _searchDoa,
              // Disable button while loading

              child: const Text('Cari Doa'),
            ),
            const SizedBox(height: 16.0),
            Expanded(
              child: SingleChildScrollView(
                child: Text(_searchResult),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}