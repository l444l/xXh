// main.dart
import 'package:flutter/material.dart';
import 'doa_detail_screen.dart'; // Pastikan Anda memiliki file ini
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';

import 'package:flutter_gemini/flutter_gemini.dart';
import 'package:myapp/doa_search_screen.dart';

void main() {
  Gemini.init(apiKey: 'AIzaSyAhK3b3IuxLNvoarNgLeDjZS8HmpgOcEqU'); // Ganti dengan API Key Gemini Anda
  runApp(const DoaHarianApp());
}
 
// 1. Perbaikan pada Class Doa
class Doa {
  final String title;
  final String arabic;
  final String latin;
  final String translation;

  // Konstruktor diperbaiki: Gunakan parameter bernama yang konsisten.
  Doa({
    required this.title,
    required this.arabic,
    required this.latin,
    required this.translation,
  });

  // Factory constructor tidak perlu diubah, tapi sekarang memanggil konstruktor yang benar.
  factory Doa.fromJson(Map<String, dynamic> json) {
    return Doa(
      title: json['doa'],
      arabic: json['ayat'],
      latin: json['latin'],
      translation: json['artinya'],
    );
  }
}

class DoaHarianApp extends StatelessWidget {
  const DoaHarianApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Doa Harian',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: DoaListScreen(),
    );
  }
}

// 2. Perbaikan pada DoaListScreen: Ubah menjadi StatefulWidget
class DoaListScreen extends StatefulWidget {
  const DoaListScreen({super.key});

  @override
  State<DoaListScreen> createState() => _DoaListScreenState();
}

class _DoaListScreenState extends State<DoaListScreen> {
  List<Doa> doaList = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDoaData();
  }

  Future<void> _loadDoaData() async {
    try {
      final String response = await rootBundle.loadString('assets/data.json');
      final data = json.decode(response) as List;
      setState(() {
        doaList = data.map((item) => Doa.fromJson(item)).toList();
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Doa Harian'),
 actions: [
 IconButton(
            icon: const Icon(Icons.search),
 onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DoaSearchScreen(),
                ),
              );
 },
 ),
 ],
        backgroundColor: Colors.green,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.separated(
              itemCount: doaList.length,
              itemBuilder: (context, index) {
                final doa = doaList[index];
                // PERUBAHAN DI SINI
                return ListTile(
                  // 1. Tambahkan widget 'leading' untuk menampilkan nomor
                  leading: CircleAvatar(
                    backgroundColor: Colors.green[100],
                    child: Text(
                      "${index + 1}",
                      style: TextStyle(
                        color: Colors.green[800],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  // 2. Teks judul doa tetap di 'title'
                  title: Text(doa.title),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DoaDetailScreen(doa: doa),
                      ),
                    );
                  },
                );
              },
              separatorBuilder: (context, index) {
                return const Divider(
                  color: Colors.grey,
                  thickness: 1,
                  indent: 16, // Memberi sedikit jarak dari tepi kiri
                  endIndent: 16, // Memberi sedikit jarak dari tepi kanan
                );
              },
            ),
    );
  }
}