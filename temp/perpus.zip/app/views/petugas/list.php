<h2>Data Petugas</h2>
<a href="index.php?page=petugas&action=form">+ Tambah Petugas</a>
<table border="1" cellpadding="8">
<tr>
 <th>No</th><th>Nama Petugas</th><th>Username</th><th>Password</th><th>Aksi</th>
</tr>
<?php $no = 1; while($row = $data->fetch_assoc()): ?>
<tr>
 <td><?= $no++ ?></td>
 <td><?= $row['nama_petugas'] ?></td>
 <td><?= $row['username'] ?></td>
 <td><?= $row['password'] ?></td>
 <td>
 <a href="index.php?page=petugas&action=form&id=<?= $row['id_petugas'] ?>">Edit</a> |
 <a href="index.php?page=petugas&action=delete&id=<?= $row['id_petugas'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
 </td>
</tr>
<?php endwhile; ?>
</table> 
