<h2><?= $petugas ? 'Edit' : 'Tambah' ?> Petugas</h2>
<form method="post" action="index.php?page=petugas&action=<?= $petugas ? 'update&id=' . $petugas['id_petugas'] :
'store' ?>">
 <label>Nama petugas:</label><br>
 <input type="text" name="nama_petugas" value="<?= $petugas['nama_petugas'] ?? '' ?>"><br>
 <label>Username:</label><br>
 <input type="text" name="username" value="<?= $petugas['username'] ?? '' ?>"><br>
 <label>Password:</label><br>
 <input type="text" name="password" value="<?= $petugas['password'] ?? '' ?>"><br>
 <button type="submit">Simpan</button>
</form> 
