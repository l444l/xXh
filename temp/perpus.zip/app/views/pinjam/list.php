<!DOCTYPE html>
<html lang="id" class=""> <!-- Kelas 'dark' akan ditambahkan di sini oleh JS -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Peminjaman - Perpustakaan Modern</title>

    <!-- Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- AOS.js for Animations -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- Custom Tailwind Config & Styles -->
    <script>
        tailwind.config = {
            darkMode: 'class', // Mengaktifkan dark mode berbasis class
            theme: {
                extend: {
                    fontFamily: {
                        'poppins': ['Poppins', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <style>
        /* Styling scrollbar agar lebih modern */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .dark ::-webkit-scrollbar-track {
            background: #2d3748;
        }
        .dark ::-webkit-scrollbar-thumb {
            background: #718096;
        }
        .dark ::-webkit-scrollbar-thumb:hover {
            background: #a0aec0;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-gray-900 font-poppins text-gray-800 dark:text-gray-200 transition-colors duration-300">

    <div id="app-container" class="flex flex-col md:flex-row min-h-screen">
        
        <!-- Navbar / Sidebar -->
        <nav class="bg-white dark:bg-gray-800 shadow-md md:w-64">
            <div class="p-4 flex justify-between items-center border-b dark:border-gray-700">
                <h1 class="text-2xl font-bold text-blue-600 dark:text-blue-400">Perpus<span class="text-purple-500">Digital</span></h1>
                <button id="mobile-menu-button" class="md:hidden p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </button>
            </div>
            <div id="menu-items" class="hidden md:block">
                <ul class="mt-4 space-y-2 px-2">
                    <li>
                        <a href="#" class="flex items-center p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                            <!-- Icon Dashboard -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="../anggota" class="flex items-center p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                             <!-- Icon Anggota -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                            Data Anggota
                        </a>
                    </li>
                    <li>
                        <a href="../buku" class="flex items-center p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                            <!-- Icon Buku -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                            Data Buku
                        </a>
                    </li>
                    <li>
                        <!-- Halaman Aktif -->
                        <a href="#" class="flex items-center p-3 rounded-lg bg-blue-500 text-white shadow-lg transition">
                            <!-- Icon Peminjaman -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"></path></svg>
                            Peminjaman
                        </a>
                    </li>
                </ul>

                <!-- Dark Mode Toggle -->
                <div class="absolute bottom-4 left-4 right-4 md:relative md:left-auto md:right-auto md:bottom-auto md:mt-10 px-2">
                    <button id="dark-mode-toggle" class="w-full flex items-center justify-center p-3 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition">
                        <svg id="sun-icon" class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                        <svg id="moon-icon" class="w-6 h-6 text-gray-300 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path></svg>
                        <span class="ml-2 text-sm font-medium">Mode</span>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="flex-1 p-4 sm:p-6 md:p-8">
            <div class="container mx-auto">
                
                <!-- Header -->
                <div data-aos="fade-down" class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
                    <h2 class="text-3xl font-bold text-gray-800 dark:text-white mb-4 sm:mb-0">Daftar Peminjaman</h2>
                    <a href="index.php?page=pinjam&action=form" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-md transition duration-300 transform hover:scale-105">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                        Tambah Peminjaman
                    </a>
                </div>

                <!-- Table Card Container -->
                <div data-aos="fade-up" data-aos-delay="200" class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <!-- Responsive Table Wrapper -->
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-white uppercase bg-gradient-to-r from-blue-600 to-purple-600">
                                <tr>
                                    <th scope="col" class="px-6 py-4">No</th>
                                    <th scope="col" class="px-6 py-4">Nama Petugas</th>
                                    <th scope="col" class="px-6 py-4">Nama Anggota</th>
                                    <th scope="col" class="px-6 py-4">Judul Buku</th>
                                    <th scope="col" class="px-6 py-4">Tgl Pinjam</th>
                                    <th scope="col" class="px-6 py-4">Tgl Kembali</th>
                                    <th scope="col" class="px-6 py-4">Status</th>
                                    <th scope="col" class="px-6 py-4 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pinjams as $index => $pinjam): ?>
                                <tr class="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition duration-200">
                                    <td class="px-6 py-4 font-medium text-gray-900 dark:text-white"><?= $index + 1 ?></td>
                                    <td class="px-6 py-4"><?= htmlspecialchars($pinjam['nama_petugas']) ?></td>
                                    <td class="px-6 py-4"><?= htmlspecialchars($pinjam['nama_anggota']) ?></td>
                                    <td class="px-6 py-4"><?= htmlspecialchars($pinjam['judul']) ?></td>
                                    <td class="px-6 py-4"><?= htmlspecialchars($pinjam['tanggal_pinjam']) ?></td>
                                    <td class="px-6 py-4"><?= htmlspecialchars($pinjam['tanggal_kembali']) ?></td>
                                    <td class="px-6 py-4">
                                        <span class="px-3 py-1 text-xs font-medium rounded-full 
                                            <?php 
                                                if ($pinjam['status'] == 'Dipinjam') echo 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
                                                elseif ($pinjam['status'] == 'Kembali') echo 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
                                                else echo 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
                                            ?>
                                        ">
                                            <?= htmlspecialchars($pinjam['status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex items-center justify-center space-x-2">
                                            <a href="index.php?page=pinjam&action=form&id=<?= $pinjam['id_peminjaman'] ?>" class="px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 text-xs font-medium rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition">Edit</a>
                                            <a href="index.php?page=pinjam&action=delete&id=<?= $pinjam['id_peminjaman'] ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')" class="px-3 py-1 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300 text-xs font-medium rounded-full hover:bg-red-200 dark:hover:bg-red-800 transition">Hapus</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- AOS.js Script -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800, // Durasi animasi
            once: true,    // Animasi hanya berjalan sekali
        });

        // --- Mobile Menu Toggle ---
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const menuItems = document.getElementById('menu-items');
        mobileMenuButton.addEventListener('click', () => {
            menuItems.classList.toggle('hidden');
        });

        // --- Dark Mode Toggle ---
        const darkModeToggle = document.getElementById('dark-mode-toggle');
        const sunIcon = document.getElementById('sun-icon');
        const moonIcon = document.getElementById('moon-icon');
        const html = document.documentElement;

        // Cek preferensi user dari local storage saat halaman dimuat
        if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            html.classList.add('dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        } else {
            html.classList.remove('dark');
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        }

        darkModeToggle.addEventListener('click', () => {
            // Toggle kelas 'dark'
            html.classList.toggle('dark');
            sunIcon.classList.toggle('hidden');
            moonIcon.classList.toggle('hidden');

            // Simpan preferensi ke local storage
            if (html.classList.contains('dark')) {
                localStorage.setItem('color-theme', 'dark');
            } else {
                localStorage.setItem('color-theme', 'light');
            }
        });

    </script>
</body>
</html>