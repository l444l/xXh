<?php
$is_edit = isset($pinjam) && $pinjam;
?>
<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale-1.0">
    <title><?= $is_edit ? 'Edit' : 'Tambah' ?> Peminjaman - Perpustakaan Modern</title>
    
    <!-- Tailwind CSS, Google Fonts, AOS (sama seperti halaman sebelumnya) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        /* Style scrollbar (opsional, untuk konsistensi) */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #888; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #555; }
        .dark ::-webkit-scrollbar-track { background: #2d3748; }
        .dark ::-webkit-scrollbar-thumb { background: #4a5568; }
    </style>
    
    <script>
        tailwind.config = { darkMode: 'class' }
    </script>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 transition-colors duration-300">

    <div class="flex h-screen">
        <!-- Sidebar/Navbar (Desktop) - SAMA PERSIS DENGAN SEBELUMNYA -->
        <nav class="bg-white dark:bg-gray-800 shadow-md md:w-64">
            <div class="p-4 flex justify-between items-center border-b dark:border-gray-700">
                <h1 class="text-2xl font-bold text-blue-600 dark:text-blue-400">Perpus<span class="text-purple-500">Digital</span></h1>
                <button id="mobile-menu-button" class="md:hidden p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </button>
            </div>
            <div id="menu-items" class="hidden md:block">
                <ul class="mt-4 space-y-2 px-2">
                    <li>
                        <a href="#" class="flex items-center p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                            <!-- Icon Dashboard -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="../anggota" class="flex items-center p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                             <!-- Icon Anggota -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                            Data Anggota
                        </a>
                    </li>
                    <li>
                        <a href="../buku" class="flex items-center p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                            <!-- Icon Buku -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                            Data Buku
                        </a>
                    </li>
                    <li>
                        <!-- Halaman Aktif -->
                        <a href="#" class="flex items-center p-3 rounded-lg bg-blue-500 text-white shadow-lg transition">
                            <!-- Icon Peminjaman -->
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"></path></svg>
                            Peminjaman
                        </a>
                    </li>
                </ul>

                <!-- Dark Mode Toggle -->
                <div class="absolute bottom-4 left-4 right-4 md:relative md:left-auto md:right-auto md:bottom-auto md:mt-10 px-2">
                    <button id="dark-mode-toggle" class="w-full flex items-center justify-center p-3 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition">
                        <svg id="sun-icon" class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                        <svg id="moon-icon" class="w-6 h-6 text-gray-300 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path></svg>
                        <span class="ml-2 text-sm font-medium">Mode</span>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header (Mobile Navbar & Title) - SAMA PERSIS DENGAN SEBELUMNYA -->
            <header class="bg-white dark:bg-gray-800 shadow-md md:hidden">
                <!-- Konten header mobile -->
            </header>
            
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900">
                <div class="container mx-auto px-6 py-8">
                    
                    <div data-aos="fade-down">
                        <h2 class="text-3xl font-semibold text-gray-800 dark:text-white">
                            <?= $is_edit ? 'Edit Peminjaman' : 'Tambah Peminjaman Baru' ?>
                        </h2>
                        <p class="mt-1 text-gray-500 dark:text-gray-400">
                            Lengkapi data di bawah ini untuk <?= $is_edit ? 'memperbarui' : 'mencatat' ?> transaksi.
                        </p>
                    </div>
                    
                    <!-- Form Container with Card Style -->
                    <div class="mt-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg" data-aos="fade-up" data-aos-delay="200">
                        <form method="post" action="index.php?page=pinjam&action=<?= $is_edit ? 'update&id=' . $pinjam['id_peminjaman'] : 'store' ?>">
                            <!-- Grid Layout for Form Fields -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                
                                <!-- Petugas -->
                                <div>
                                    <label for="id_petugas" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nama Petugas</label>
                                    <select id="id_petugas" name="id_petugas" required class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                                        <option value="">Pilih Petugas</option>
                                        <?php foreach ($petugass as $petugas): ?>
                                            <option value="<?= $petugas['id_petugas'] ?>" <?= ($is_edit && $pinjam['id_petugas'] == $petugas['id_petugas']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($petugas['nama_petugas']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Anggota -->
                                <div>
                                    <label for="id_anggota" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nama Anggota</label>
                                    <select id="id_anggota" name="id_anggota" required class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                                        <option value="">Pilih Anggota</option>
                                        <?php foreach ($anggotas as $anggota): ?>
                                            <option value="<?= $anggota['id_anggota'] ?>" <?= ($is_edit && $pinjam['id_anggota'] == $anggota['id_anggota']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($anggota['nama_anggota']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Buku -->
                                <div class="md:col-span-2">
                                    <label for="id_buku" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Judul Buku</label>
                                    <select id="id_buku" name="id_buku" required class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                                        <option value="">Pilih Buku</option>
                                        <?php foreach ($bukus as $buku): ?>
                                            <option value="<?= $buku['id_buku'] ?>" <?= ($is_edit && $pinjam['id_buku'] == $buku['id_buku']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($buku['judul']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Tanggal Pinjam -->
                                <div>
                                    <label for="tanggal_pinjam" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Tanggal Pinjam</label>
                                    <input type="date" id="tanggal_pinjam" name="tanggal_pinjam" value="<?= $is_edit ? htmlspecialchars($pinjam['tanggal_pinjam']) : '' ?>" required class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                                </div>

                                <!-- Tanggal Kembali -->
                                <div>
                                    <label for="tanggal_kembali" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Tanggal Kembali</label>
                                    <input type="date" id="tanggal_kembali" name="tanggal_kembali" value="<?= $is_edit ? htmlspecialchars($pinjam['tanggal_kembali']) : '' ?>" required class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                                </div>

                                <!-- Status -->
                                <div>
                                    <label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Status</label>
                                    <select id="status" name="status" required class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                                        <option value="Dipinjam" <?= ($is_edit && $pinjam['status'] == 'Dipinjam') ? 'selected' : '' ?>>Dipinjam</option>
                                        <option value="Kembali" <?= ($is_edit && $pinjam['status'] == 'Kembali') ? 'selected' : '' ?>>Kembali</option>
                                        <option value="Terlambat" <?= ($is_edit && $pinjam['status'] == 'Terlambat') ? 'selected' : '' ?>>Terlambat</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="mt-8 flex justify-end space-x-4">
                                <a href="index.php" class="px-6 py-2 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-semibold rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition duration-200">
                                    Batal
                                </a>
                                <button type="submit" class="inline-flex items-center px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-transform transform hover:scale-105">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M7.875 1.563A.937.937 0 006.938 2.5v15a.938.938 0 001.875 0V2.5A.937.937 0 007.875 1.563zM3.125 4.375A.938.938 0 002.188 5.312v9.375a.938.938 0 001.875 0V5.312a.938.938 0 00-.938-.937zM12.5 4.375a.938.938 0 00-.938.937v9.375a.938.938 0 001.875 0V5.312A.938.938 0 0012.5 4.375zM16.875 6.25a.938.938 0 00-.938.938v5.625a.938.938 0 001.875 0V7.188a.938.938 0 00-.938-.938z" />
                                    </svg>
                                    Simpan Data
                                </button>
                            </div>
                        </form>
                    </div>

                </div>
            </main>
        </div>
    </div>
    
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800, // Durasi animasi
            once: true,    // Animasi hanya berjalan sekali
        });

        // --- Mobile Menu Toggle ---
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const menuItems = document.getElementById('menu-items');
        mobileMenuButton.addEventListener('click', () => {
            menuItems.classList.toggle('hidden');
        });

        // --- Dark Mode Toggle ---
        const darkModeToggle = document.getElementById('dark-mode-toggle');
        const sunIcon = document.getElementById('sun-icon');
        const moonIcon = document.getElementById('moon-icon');
        const html = document.documentElement;

        // Cek preferensi user dari local storage saat halaman dimuat
        if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            html.classList.add('dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        } else {
            html.classList.remove('dark');
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        }

        darkModeToggle.addEventListener('click', () => {
            // Toggle kelas 'dark'
            html.classList.toggle('dark');
            sunIcon.classList.toggle('hidden');
            moonIcon.classList.toggle('hidden');

            // Simpan preferensi ke local storage
            if (html.classList.contains('dark')) {
                localStorage.setItem('color-theme', 'dark');
            } else {
                localStorage.setItem('color-theme', 'light');
            }
        });

    </script>
</body>
</html>