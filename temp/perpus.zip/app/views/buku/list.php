<h2>Data Buku</h2>
<a href="index.php?page=buku&action=form">+ Tambah Buku</a>
<table border="1" cellpadding="8">
<tr>
 <th>No</th><th>Judul</th><th>Penulis</th><th>Penerbit</th><th>Tahun Terbit</th><th>Stok</th><th>Aksi</th>
</tr>
<?php $no = 1; while($row = $data->fetch_assoc()): ?>
<tr>
 <td><?= $no++ ?></td>
 <td><?= $row['judul'] ?></td>
 <td><?= $row['penulis'] ?></td>
 <td><?= $row['penerbit'] ?></td>
 <td><?= $row['tahun_terbit'] ?></td>
 <td><?= $row['stok'] ?></td>
 <td>
 <a href="index.php?page=buku&action=form&id=<?= $row['id_buku'] ?>">Edit</a> |
 <a href="index.php?page=buku&action=delete&id=<?= $row['id_buku'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
 </td>
</tr>
<?php endwhile; ?>
</table> 
