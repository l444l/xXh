<h2><?= $buku ? 'Edit' : 'Tambah' ?> Buku</h2>
<form method="post" action="index.php?page=buku&action=<?= $buku ? 'update&id=' . $buku['id_buku'] :
'store' ?>">
 <label>Judul:</label><br>
 <input type="text" name="judul" value="<?= $buku['judul'] ?? '' ?>"><br>
 <label>Penulis:</label><br>
 <input type="text" name="penulis" value="<?= $buku['penulis'] ?? '' ?>"><br>
 <label>Penerbit:</label><br>
 <input type="text" name="penerbit" value="<?= $buku['penerbit'] ?? '' ?>"><br>
 <label>Tahun Terbit:</label><br>
 <input type="text" name="tahun_terbit" value="<?= $buku['tahun_terbit'] ?? '' ?>"><br>
 <label>Stok:</label><br>
 <input type="text" name="stok" value="<?= $buku['stok'] ?? '' ?>"><br>
 <button type="submit">Simpan</button>
</form> 
