<?php
$is_edit = isset($anggota) && $anggota;
?>
<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $is_edit ? 'Edit' : 'Tambah' ?> Anggota - Perpustakaan Modern</title>
    
    <!-- Tailwind CSS, Google Fonts, AOS (sama seperti halaman sebelumnya) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        /* Style scrollbar (opsional, untuk konsistensi) */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #888; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #555; }
        .dark ::-webkit-scrollbar-track { background: #2d3748; }
        .dark ::-webkit-scrollbar-thumb { background: #4a5568; }
    </style>
    
    <script>
        tailwind.config = { darkMode: 'class' }
    </script>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 transition-colors duration-300">

    <div class="flex h-screen">
        <!-- Sidebar/Navbar (Desktop) -->
        <aside class="w-64 bg-white dark:bg-gray-800 shadow-md hidden md:flex flex-col">
            <div class="p-6 text-2xl font-bold text-blue-600 dark:text-blue-400 border-b dark:border-gray-700">
                Perpus<span class="text-purple-500">Digital</span>
            </div>
            <nav class="flex-1 px-4 py-4 space-y-2">
                <a href="#" class="flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                    <!-- Icon Dashboard -->
                    Dashboard
                </a>
                <!-- MENU AKTIF DI SINI -->
                <a href="#" class="flex items-center px-4 py-2 text-white bg-gradient-to-r from-blue-500 to-purple-600 rounded-md">
                    <!-- Icon Anggota -->
                    Data Anggota
                </a>
                <a href="#" class="flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                    <!-- Icon Buku -->
                    Data Buku
                </a>
                <a href="#" class="flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                    <!-- Icon Peminjaman -->
                    Peminjaman
                </a>
            </nav>
            <div class="p-4 border-t dark:border-gray-700">
                <!-- Dark Mode Toggle (sama seperti sebelumnya) -->
            </div>
        </aside>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header (Mobile Navbar) akan sama -->
            
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900">
                <div class="container mx-auto px-6 py-8">
                    
                    <div data-aos="fade-down">
                        <h2 class="text-3xl font-semibold text-gray-800 dark:text-white">
                            <?= $is_edit ? 'Edit Data Anggota' : 'Tambah Anggota Baru' ?>
                        </h2>
                        <p class="mt-1 text-gray-500 dark:text-gray-400">
                            Masukkan informasi anggota dengan lengkap dan benar.
                        </p>
                    </div>
                    
                    <!-- Form Container with Card Style -->
                    <div class="mt-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg" data-aos="fade-up" data-aos-delay="200">
                        <form method="post" action="index.php?page=anggota&action=<?= $is_edit ? 'update&id=' . $anggota['id_anggota'] : 'store' ?>">
                            
                            <div class="space-y-6">
                                
                                <!-- Nama Anggota -->
                                <div>
                                    <label for="nama_anggota" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nama Lengkap</label>
                                    <input type="text" id="nama_anggota" name="nama_anggota" value="<?= htmlspecialchars($anggota['nama_anggota'] ?? '') ?>" required
                                           class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200"
                                           placeholder="Contoh: Budi Santoso">
                                </div>

                                <!-- Alamat -->
                                <div>
                                    <label for="alamat" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Alamat</label>
                                    <textarea id="alamat" name="alamat" rows="3" required
                                              class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200"
                                              placeholder="Contoh: Jl. Merdeka No. 17, Jakarta"><?= htmlspecialchars($anggota['alamat'] ?? '') ?></textarea>
                                </div>
                                
                                <!-- No HP -->
                                <div>
                                    <label for="no_hp" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Nomor HP</label>
                                    <input type="tel" id="no_hp" name="no_hp" value="<?= htmlspecialchars($anggota['no_hp'] ?? '') ?>" required
                                           class="block w-full px-4 py-2 text-gray-900 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200"
                                           placeholder="Contoh: 081234567890">
                                </div>

                            </div>

                            <!-- Action Buttons -->
                            <div class="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 flex justify-end space-x-4">
                                <a href="index.php?page=anggota" class="px-6 py-2 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-semibold rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition duration-200">
                                    Batal
                                </a>
                                <button type="submit" class="inline-flex items-center px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-transform transform hover:scale-105">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                                    </svg>
                                    Simpan Anggota
                                </button>
                            </div>
                        </form>
                    </div>

                </div>
            </main>
        </div>
    </div>
    
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
        // Script untuk dark mode & mobile menu (sama seperti halaman sebelumnya)
        // ...
    </script>
</body>
</html>