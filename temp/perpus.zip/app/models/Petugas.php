<?php
    class Petugas {
        private $conn;
        public function __construct($conn) {
            $this->conn = $conn;
        }
        public function getAll() {
            return $this->conn->query("SELECT * FROM petugas");
        }
        public function getById($id_petugas) {
            $stmt = $this->conn->prepare("SELECT * FROM petugas WHERE id_petugas = ?");
            $stmt->bind_param("i", $id_petugas);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }
        public function create($data) {
            $stmt = $this->conn->prepare("INSERT INTO petugas (nama_petugas, username, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $data['nama_petugas'], $data['username'], $data['password']);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }
        public function update($id_petugas, $data) {
            $stmt = $this->conn->prepare("UPDATE petugas SET nama_petugas=?, username=?, password=? WHERE id_petugas=?");
            $stmt->bind_param("sssi", $data['nama_petugas'], $data['username'], $data['password'], $id_petugas);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }
        public function delete($id_petugas) {
            $stmt = $this->conn->prepare("DELETE FROM petugas WHERE id_petugas=?");
            $stmt->bind_param("i", $id_petugas);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }
    }
?>
