<?php
    class Buku {
        private $conn;
        public function __construct($conn) {
            $this->conn = $conn;
        }
        public function getAll() {
            return $this->conn->query("SELECT * FROM buku");
        }
        public function getById($id_buku) {
            $stmt = $this->conn->prepare("SELECT * FROM buku WHERE id_buku = ?");
            $stmt->bind_param("i", $id_buku);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }
        public function create($data) {
            $stok = (int)$data['stok'];
            $stmt = $this->conn->prepare("INSERT INTO buku (judul, penulis, penerbit, tahun_terbit, stok) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssi", $data['judul'], $data['penulis'], $data['penerbit'], $data['tahun_terbit'], $stok);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }

        public function update($id_buku, $data) {
            $stok = (int)$data['stok'];
            $stmt = $this->conn->prepare("UPDATE buku SET judul=?, penulis=?, penerbit=?, tahun_terbit=?, stok=? WHERE id_buku=?");
            $stmt->bind_param("ssssii", $data['judul'], $data['penulis'], $data['penerbit'], $data['tahun_terbit'], $stok, $id_buku);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }

        public function delete($id_buku) {
            $stmt = $this->conn->prepare("DELETE FROM buku WHERE id_buku=?");
            $stmt->bind_param("i", $id_buku);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }
    }
?>
