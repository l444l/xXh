<?php
    class Anggota {
        private $conn;
        public function __construct($db) {
            $this->conn = $db;
        }
        public function getAll() {
            return $this->conn->query("SELECT * FROM anggota");
        }
        public function getById($id_anggota) {
            $stmt = $this->conn->prepare("SELECT * FROM anggota WHERE id_anggota = ?");
            $stmt->bind_param("i", $id_anggota);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }
        public function create($data) {
            $stok = (int)$data['stok'];
            $stmt = $this->conn->prepare("INSERT INTO anggota (nama_anggota, alamat, no_hp) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $data['nama_anggota'], $data['alamat'], $data['no_hp']);
            return $stmt->execute();    
        }
        public function update($id_anggota, $data) {
            $stok = (int)$data['stok'];
            $stmt = $this->conn->prepare("UPDATE anggota SET nama_anggota=?, alamat=?, no_hp=? WHERE id_anggota=?");
            $stmt->bind_param("sssi", $data['nama_anggota'], $data['alamat'], $data['no_hp'], $id_anggota);
            return $stmt->execute();
        }
        public function delete($id_anggota) {
            $stmt = $this->conn->prepare("DELETE FROM anggota WHERE id_anggota=?");
            $stmt->bind_param("i", $id_anggota);
            return $stmt->execute();
        }
    }
?>
