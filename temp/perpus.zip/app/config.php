<?php
    $host = "127.0.0.1";
    $user = "root";
    $pass = "";
    $dbname = "db_perpustakaan";

    $conn = new mysqli($host, $user, $pass, $dbname);

    $conn = new mysqli($host, $user, $pass, $dbname);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }
?> 
