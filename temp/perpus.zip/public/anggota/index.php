<?php
    require_once '../../app/config.php';
    require_once '../../app/controllers/AnggotaController.php';
    $page = $_GET['page'] ?? 'anggota';
    $action = $_GET['action'] ?? 'list';
    $id = $_GET['id'] ?? null;
    $controller = new AnggotaController($conn);
    if ($page === 'anggota') {
        if ($action === 'list') {
            $controller->viewList();
        } elseif ($action === 'form') {
            $controller->viewForm($id);
        } elseif ($action === 'store') {
            $controller->store();
        } elseif ($action === 'update') {
            $controller->update($id);
        } elseif ($action === 'delete') {
            $controller->delete($id);
        } elseif ($action === 'api') {
            $method = $_SERVER['REQUEST_METHOD'];
            $apiId = $_GET['api_id'] ?? null;
            $controller->api($method, $apiId);
        } else {
            echo "Aksi tidak dikenali.";
        }
    } else {
        echo "Halaman tidak dikenali.";
    }
?> 