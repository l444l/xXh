# Created by Li
# Modified by Wadudi

import PlayFab
import json

def main(custom_id):
    # Login and Switch to Master Player Account
    PlayFab.GetEntityToken(PlayFab.LoginWithCustomId()['PlayFabId'], 'master_player_account')

    MAX_SEARCH = 300
    MAX_SKIP = 10000

    # Get total number of items in marketplace
    totalItems = PlayFab.Search("", "creationDate ASC", None, 1, 0, custom_id)["Count"]

    # Initialize some variables
    searchFilter = ""
    skip = 0
    resultsDict = {}

    # Search loop
    while len(resultsDict) < totalItems:
        searchResults = PlayFab.Search("", "creationDate ASC", "contents", MAX_SEARCH, skip, custom_id)

        for item in searchResults["Items"]:
            resultsDict[item["Id"]] = item

        skip += MAX_SEARCH

        if skip > MAX_SKIP:
            searchFilter = "(CreationDate ge " + searchResults["Items"][-1]["CreationDate"] +")";
            skip = 0

    # Write results to cache.json
    with open("cache.json", "w", encoding="utf-8") as f:
        json.dump(resultsDict, f, indent=4)

if __name__ == "__main__":
    import sys
    custom_id = sys.argv[1]
    main(custom_id)
