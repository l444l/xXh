import os
import struct
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import json
import zipfile
import shutil
from colorama import Fore, Style
import colorama


def aes256_cfb_decrypt(key, iv, data):
  decryptor = AES.new(key, AES.MODE_CFB, iv)
  decrypted_data = decryptor.decrypt(data)
  return decrypted_data

def world_or_contents_json_decrypt(file_path):
    with open(file_path, 'rb') as file:
        header = file.read(17)  # Read the header

        # Read and unpack the header values
        _, magic, _, uuid_length = struct.unpack('<IIQb', header)
        uuid = file.read(uuid_length).decode('utf-8')  # Read the UUID

        if magic == 0x9BCFB9FC:  # Check for the expected magic number
            key = b's5s5ejuDru4uchuF2drUFuthaspAbepE'

            file.seek(0x100)  # Skip header
            encrypted_data = file.read()  # Read the encrypted data

            iv = key[:16]  # Use the first 16 bytes of the key as IV

            decrypted_data = aes256_cfb_decrypt(key, iv, encrypted_data)
            return decrypted_data, uuid
        else:
            raise ValueError("Not a valid LEVELDB or CONTENTS.JSON file.")

def decrypt_custom_file(file_path, key):
  with open(file_path, 'rb') as file:
    encrypted_data = file.read()
    iv = key[:16]  # Use the first 16 bytes of the key as IV
    decrypted_data = aes256_cfb_decrypt(key, iv, encrypted_data)
    return decrypted_data

def find_files(directory, file_name=None):
  for root, _, filenames in os.walk(directory):
    for filename in filenames:
      if file_name is None or filename == file_name:
        yield os.path.join(root, filename)

def decrypt_files_for_contents_json(contents_json_file, key):
  with open(contents_json_file, 'r', encoding='utf-8') as f:
    data = json.load(f)
    content_array = data.get("content", [])
    for entry in content_array:
      if "key" in entry and "path" in entry:
        key = entry["key"]
        path = entry["path"]
        target_file_path = os.path.join(os.path.dirname(contents_json_file), path)
        decrypted_data = decrypt_custom_file(target_file_path, key.encode('utf-8'))
        with open(target_file_path, 'wb') as target_file:
          target_file.write(decrypted_data)
    print("Files decrypted")

def decrypt_files(root_directory, key):
    # Decrypt contents.json files first
    contents_json_files = find_files(root_directory, "contents.json")
    for contents_json_file in contents_json_files:
        decrypted_data, _ = world_or_contents_json_decrypt(contents_json_file)
        with open(contents_json_file, 'wb') as f:
            f.write(decrypted_data)
        print("Decrypted contents.json:", contents_json_file)
        decrypt_files_for_contents_json(contents_json_file, key)

def modify_sk_json(root_directory):
    for dirpath, _, filenames in os.walk(root_directory):
        for filename in filenames:
            if filename == "skins.json":
                sk_json_file = os.path.join(dirpath, filename)
                with open(sk_json_file, "r+") as f:
                    file_data = f.read()
                    modified_data = file_data.replace("paid", "free")
                    f.seek(0)
                    f.write(modified_data)
                    f.truncate()
                print("skins.json modified:", sk_json_file)

def extract_zip(zip_file_path, extract_to):
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print("Extracted zip file to:", extract_to)

def list_zip_files():
    zip_files = [file for file in os.listdir() if file.endswith('.zip')]
    for i, zip_file in enumerate(zip_files, start=1):
        file_size_mb = os.path.getsize(zip_file) / (1024 * 1024)  # Size in MB
        print(f"{i}) {zip_file}  {file_size_mb:.2f} MB")
    return zip_files

def main(pack_folder):
    if os.path.isdir(pack_folder):
        # Look for contents.json in the extracted folder
        contents_json_files = find_files(pack_folder, "contents.json")
        if contents_json_files:
            key = b's5s5ejuDru4uchuF2drUFuthaspAbepE'  # Key for decryption
            # Decrypt files in the extracted folder
            decrypt_files(pack_folder, key)
            # Modify skins.json
            modify_sk_json(pack_folder)
            # Get skin pack name from en_US.lang file
            skin_pack_name = get_skin_pack_name(pack_folder)
            # Compress the decrypted files into a new zip file with the skin pack name
            compress_to_zip(pack_folder, skin_pack_name)
        else:
            print("contents.json file not found in the extracted folder:", pack_folder)
    else:
        print("Invalid pack folder path:", pack_folder)


def remove_forbidden_chars(name):
    # Define a list of characters to remove
    forbidden_chars = ['#', ':', '?', '/', '<', '>']

    # Remove forbidden characters
    for char in forbidden_chars:
        name = name.replace(char, '')

    return name

def get_skin_pack_name(extracted_folder_path):
    lang_file_path = os.path.join(extracted_folder_path, "texts", "en_US.lang")
    with open(lang_file_path, 'rb') as lang_file:
        # Check for BOM and skip it
        bom = lang_file.read(3)
        if bom != b'\xef\xbb\xbf':
            lang_file.seek(0)
        first_line = lang_file.readline()
        try:
            decoded_line = first_line.decode('utf-8')
        except UnicodeDecodeError:
            decoded_line = first_line.decode('utf-8', errors='ignore')  # Skip problematic characters
        skin_pack_name = decoded_line.split('=')[-1].strip()
        skin_pack_name = skin_pack_name.replace('\t', ' ')
        # Remove forbidden characters from the pack name
        skin_pack_name = remove_forbidden_chars(skin_pack_name)
    return skin_pack_name

def compress_to_zip(source_folder, skin_pack_name):
    zip_filename = f"{skin_pack_name} (skin_pack).mcpack"
    zip_file_path = os.path.join(os.path.dirname(source_folder), zip_filename)
    
    # Check if the file already exists in "packs" folder
    destination_path = os.path.join("packs", zip_filename)
    if os.path.exists(destination_path):
        # Append a sequential number to the filename
        count = 1
        while True:
            new_filename = f"{skin_pack_name} (skin_pack)_{count}.mcpack"
            new_file_path = os.path.join(os.path.dirname(source_folder), new_filename)
            if not os.path.exists(os.path.join("packs", new_filename)):
                break
            count += 1
        zip_filename = new_filename
        destination_path = os.path.join("packs", zip_filename)
    
    with zipfile.ZipFile(zip_file_path, 'w') as zipf:
        for root, dirs, files in os.walk(source_folder):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, source_folder))
    print("Compressed decrypted files into:", Fore.YELLOW + zip_filename + Style.RESET_ALL)
    
    # Move the zip file to "packs" folder
    shutil.move(zip_file_path, destination_path)


if __name__ == "__main__":
    main()