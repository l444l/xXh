import os
import struct
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import json
import zipfile
import shutil
import colorama
from colorama import Fore, Style

def aes256_cfb_decrypt(key, iv, data):
  decryptor = AES.new(key, AES.MODE_CFB, iv)
  decrypted_data = decryptor.decrypt(data)
  return decrypted_data

def world_or_contents_json_decrypt(file_path, keys_file):
  with open(file_path, 'rb') as file:
    header = file.read(17)  # Read the header
    _, magic, _, uuid_length = struct.unpack('<IIQb', header)
    uuid = file.read(uuid_length).decode('utf-8')  # Read the UUID

    if magic == 0x9BCFB9FC:  # Check for the expected magic number
      key = get_key_from_tsv(keys_file, uuid)
      if key:
        file.seek(0x100)  # Skip header
        encrypted_data = file.read()  # Read the encrypted data
        iv = key[:16]  # Use the first 16 bytes of the key as IV
        decrypted_data = aes256_cfb_decrypt(key, iv, encrypted_data)
        return decrypted_data, uuid
      else:
        raise ValueError("Key not found for the DLC")
    else:
      raise ValueError("Not a valid contents.json file.")

def get_key_from_tsv(keys_file, uuid):
  with open(keys_file, 'r') as f:
    for line in f:
      fields = line.strip().split('\t')
      if len(fields) >= 4 and fields[1] == uuid:
        return fields[3].encode('utf-8')  # Convert the key to bytes
  return None

def decrypt_custom_file(file_path, key):
  with open(file_path, 'rb') as file:
    encrypted_data = file.read()
    iv = key[:16]  # Use the first 16 bytes of the key as IV
    decrypted_data = aes256_cfb_decrypt(key, iv, encrypted_data)
    return decrypted_data

def find_files(directory, file_name=None):
  for root, _, filenames in os.walk(directory):
    for filename in filenames:
      if file_name is None or filename == file_name:
        yield os.path.join(root, filename)

def decrypt_files_for_contents_json(contents_json_file, key):
    with open(contents_json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        content_array = data.get("content", [])
        total_files = len(content_array)
        files_processed = 0
        for entry in content_array:
            if "key" in entry and "path" in entry:
                key = entry["key"]
                path = entry["path"]
                target_file_path = os.path.join(os.path.dirname(contents_json_file), path)
                decrypted_data = decrypt_custom_file(target_file_path, key.encode('utf-8'))
                with open(target_file_path, 'wb') as target_file:
                    target_file.write(decrypted_data)
                files_processed += 1
                progress = (files_processed / total_files) * 100
                print(f"Decrypting packs {progress:.2f}% completed", end='\r')
        # Print final completion message after loop ends
        print("Packs decrypted.                 ")

def decrypt_files(root_directory, keys_file):
    contents_json_files = list(find_files(root_directory, "contents.json"))
    total_files = len(contents_json_files)
    files_processed = 0
    
    for contents_json_file in contents_json_files:
        decrypted_data, _ = world_or_contents_json_decrypt(contents_json_file, keys_file)
        with open(contents_json_file, 'wb') as f:
            f.write(decrypted_data)
        print("Decrypted contents.json:", contents_json_file)
        decrypt_files_for_contents_json(contents_json_file, keys_file)

    db_folder_path = os.path.join(root_directory, "db")
    db_files = list(find_files(db_folder_path))
    total_files += len(db_files)
    
    for i, db_file in enumerate(db_files, start=1):
        # Check if the file is empty
        if os.path.getsize(db_file) == 0:
            print("Skipping decryption for empty file:", db_file)
            continue

        if "lost" in os.path.dirname(db_file):
            continue

        decrypted_data, _ = world_or_contents_json_decrypt(db_file, keys_file)
        with open(db_file, 'wb') as f:
            f.write(decrypted_data)
        
        files_processed += 1
        progress = (files_processed / total_files) * 100
        print(f"Decrypted db file ({progress:.2f}%): {db_file}", end='\r')

    # Print final completion message after loop ends
    print("Files on db decrypted.                                             ")


def modify_file(file_path):
    with open(file_path, "r+b") as f:
        file_data = f.read()
        search_bytes = b"prid"
        replacement_bytes = b"pria"
        offset = file_data.find(search_bytes)
        while offset != -1:
            file_data = file_data[:offset] + replacement_bytes + file_data[offset + len(search_bytes):]
            offset = file_data.find(search_bytes, offset + len(replacement_bytes))
        f.seek(0)
        f.write(file_data)
        f.truncate()
        print("Modified:", file_path)

def modify_level_dat(root_directory):
    level_dat_file = os.path.join(root_directory, "level.dat")
    if os.path.exists(level_dat_file):
        modify_file(level_dat_file)
    else:
        print("level.dat not found.")
        return False  # Indicate that level.dat was not found
    return True

def extract_zip(zip_file_path, extract_to):
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print("Extracted zip file to:", extract_to)

def main(extracted_folder, keys_file):
    # Check if the extracted folder directly contains manifest.json
    manifest_path = os.path.join(extracted_folder, "manifest.json")
    if not os.path.exists(manifest_path):
        # Assume the pack content is within a subfolder of the extracted folder
        subfolders = [f for f in os.listdir(extracted_folder) if os.path.isdir(os.path.join(extracted_folder, f))]
        if len(subfolders) == 1:
            pack_folder = os.path.join(extracted_folder, subfolders[0])
            print("Found pack folder:", pack_folder)
        else:
            print("Unable to determine pack folder within the extracted directory.")
            return
    else:
        pack_folder = extracted_folder

    with open(manifest_path, 'r') as manifest_file:
        manifest_data = json.load(manifest_file)
        first_uuid = manifest_data.get("header", {}).get("uuid")

    if first_uuid:
        # Decrypt files using the key corresponding to the first UUID in manifest.json
        key = get_key_from_tsv(keys_file, first_uuid)
        if key:
            decrypt_files(pack_folder, keys_file)
            modify_level_dat(pack_folder)
            skin_pack_name = get_skin_pack_name(pack_folder)
            # Determine the zip file name based on whether level.dat was modified
            if os.path.exists(os.path.join(pack_folder, "level.dat")):
                zip_filename = f"{skin_pack_name} (world_template).mctemplate"
            else:
                zip_filename = f"{skin_pack_name} (resources).mcpack"
            compress_to_zip(pack_folder, skin_pack_name, zip_filename)
        else:
            print("Key not found for the DLC")
    else:
        print("UUID not found in manifest.json")

def remove_forbidden_chars(name):
    # Define a list of characters to remove
    forbidden_chars = ['#', ':', '?', '/', '<', '>']

    # Remove forbidden characters
    for char in forbidden_chars:
        name = name.replace(char, '')

    return name

def get_skin_pack_name(extracted_folder_path):
    lang_file_path = os.path.join(extracted_folder_path, "texts", "en_US.lang")
    with open(lang_file_path, 'rb') as lang_file:
        # Check for BOM and skip it
        bom = lang_file.read(3)
        if bom != b'\xef\xbb\xbf':
            lang_file.seek(0)
        for line in lang_file:
            try:
                decoded_line = line.decode('utf-8')
            except UnicodeDecodeError:
                decoded_line = line.decode('utf-8', errors='ignore')  # Skip problematic characters
            if decoded_line.startswith("pack.name="):
                skin_pack_name = decoded_line[len("pack.name="):].strip()
                # Replace tabs with spaces in the pack name
                skin_pack_name = skin_pack_name.replace('\t', ' ')
                # Remove forbidden characters from the pack name
                skin_pack_name = remove_forbidden_chars(skin_pack_name)
                return skin_pack_name
    print("Error: pack name not found on en_US.lang")
    return None

def compress_to_zip(source_folder, skin_pack_name, zip_file_path):
    print("Compressing decrypted files... ")
    # Check if the zip file already exists, if so, append a sequential number
    i = 1
    while os.path.exists(zip_file_path):
        base_name, extension = os.path.splitext(zip_file_path)
        zip_file_path = f"{base_name}_{i}{extension}"
        i += 1
    
    with zipfile.ZipFile(zip_file_path, 'w') as zipf:
        for root, dirs, files in os.walk(source_folder):
            for file in files:
                file_path = os.path.join(root, file)
                # Exclude files named "signatures.json" and "contents.json"
                if file not in ["signatures.json", "contents.json"]:
                    zipf.write(file_path, os.path.relpath(file_path, source_folder))
    
    # Get only the filename from the zip file path
    zip_filename = os.path.basename(zip_file_path)
    print("Compressed decrypted files into:", end=" ")
    print(Fore.YELLOW + zip_filename)
    print(Style.RESET_ALL)

    # Move the compressed file to the "packs" directory
    destination_file = os.path.join("packs", zip_filename)
    if os.path.exists(destination_file):
        # If the destination file already exists, append a sequential number
        base_name, extension = os.path.splitext(destination_file)
        i = 1
        while os.path.exists(destination_file):
            destination_file = f"{base_name}_{i}{extension}"
            i += 1
    shutil.move(zip_file_path, destination_file)

def remove_extracted_folder(extracted_folder):
    # Check if the folder exists before attempting to remove it
    if os.path.exists(extracted_folder):
        shutil.rmtree(extracted_folder)
        parent_folder = os.path.dirname(extracted_folder)
        if os.path.exists(parent_folder):
            shutil.rmtree(parent_folder)

def list_zip_files():
    zip_files = [file for file in os.listdir() if file.endswith('.zip')]
    for i, zip_file in enumerate(zip_files, start=1):
        file_size_mb = os.path.getsize(zip_file) / (1024 * 1024)  # Size in MB
        print(f"{i}) {zip_file}  {file_size_mb:.2f} MB")
    return zip_files

if __name__ == "__main__":
    zip_files = list_zip_files()
    if zip_files:
        print()
        selection = input(colorama.Fore.YELLOW + "Select what to decrypt: " + colorama.Style.RESET_ALL)
        try:
            selection_index = int(selection)
            if 1 <= selection_index <= len(zip_files):
                enc_zip_file = zip_files[selection_index - 1]
                keys_file = os.path.join(os.getcwd(), "keys.tsv")
                main(enc_zip_file, keys_file)
            else:
                print("Invalid selection.")
        except ValueError:
            print("Invalid selection. Please enter a number.")
    else:
        print("No zip files found in the directory.")