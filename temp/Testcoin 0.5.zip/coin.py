import json
import os
import requests
import shutil
import zipfile
import uuid
import threading
import platform
import colorama
import Scraper
import re
from dlc import remove_extracted_folder
import skin
import dlc

def clear_console():
    os_name = platform.system()
    if os_name == 'Windows':
        os.system('cls')
    else:
        os.system('clear')

clear_console()

# Initialize colorama
colorama.init()

title = colorama.Fore.YELLOW + """
 _____         _            _       
|_   _|       | |          (_)      
  | | ___  ___| |_ ___ ___  _ _ __  
  | |/ _ \/ __| __/ __/ _ \| | '_ \ 
  | |  __/\__ \ || (_| (_) | | | | |
  \_/\___||___/\__\___\___/|_|_| |_| 0.5""" + colorama.Style.RESET_ALL

print(title)
print()


def download_progress(downloaded, total_size):
    percent = int((downloaded / total_size) * 100)
    print(f"\rDownloading: {percent}%", end="", flush=True)

def ensure_unique_folder_name(folder_path):
    if not os.path.exists(folder_path):
        return folder_path
    
    base_name, extension = os.path.splitext(folder_path)
    i = 1
    while os.path.exists(folder_path):
        folder_path = f"{base_name}_{i}{extension}"
        i += 1
    return folder_path

folder_lock = threading.Lock()

def rename_extracted_folders(extracted_folders, user_input, pack_type):
    renamed_folders = []
    for i, (pack_name, pack_folder) in enumerate(extracted_folders):
        if os.path.exists(pack_folder):  # Check if the folder exists
            new_folder_name = f"{user_input}_{pack_type}_{i+1}"
            new_pack_folder = ensure_unique_folder_name(os.path.join(os.path.dirname(pack_folder), new_folder_name))
            try:
                # Acquire the lock before renaming the folder
                folder_lock.acquire()
                shutil.move(pack_folder, new_pack_folder)
                renamed_folders.append((pack_name, new_pack_folder))
            except FileNotFoundError:
                print(f"Error: Original folder '{pack_folder}' not found.")
            except FileExistsError:
                print(f"Error: Unable to rename '{pack_folder}' to '{new_pack_folder}'. File already exists.")
            finally:
                # Release the lock regardless of whether an exception occurred
                folder_lock.release()
        else:
            print(f"Error: Original folder '{pack_folder}' not found.")
    return renamed_folders

# Extract ID from URL
def extract_id_from_url(url):
    pattern = r'id=([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})'
    match = re.search(pattern, url)
    if match:
        return match.group(1)
    else:
        return None

def check_custom_id(custom_id):
    with open("keys.tsv", "r") as keys_file:
        for line in keys_file:
            if custom_id in line:
                return True
    return False    

def get_custom_id():
    while True:
        user_input = input("Enter the UUID or URL: ")
        if "id=" in user_input:
            return extract_id_from_url(user_input)
        # If the input appears to be a valid ID, return it directly
        elif re.match(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}', user_input):
            return user_input
        else:
            print("Invalid input. Please enter a valid UUID or URL.")

def download_and_process_zip(zip_url, user_input, pack_type):
    timeout = 60  # Adjust timeout as needed

    try:
        response = requests.get(zip_url, timeout=timeout, headers={"User-Agent": "libhttpclient/1.0.0.0"}, stream=True)
        response.raise_for_status()

        total_size = int(response.headers.get('content-length', 0))
        downloaded_size = 0

        url_parts = zip_url.split("/")
        zip_filename = url_parts[-1]

        output_folder = "packs"
        random_folder_name = uuid.uuid4().hex
        pack_folder = os.path.join(output_folder, random_folder_name)

        os.makedirs(pack_folder, exist_ok=True)

        # Download the ZIP file
        zip_file_path = os.path.join(pack_folder, zip_filename)
        with open(zip_file_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
                downloaded_size += len(chunk)
                download_progress(downloaded_size, total_size)

        print("\rDownload completed")

        print("\rExtracting zip file...")
        extracted_pack_folders = []  # List to store the folder paths of the extracted packages
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            for name in zip_ref.namelist():
                if name.endswith('.zip'):
                    nested_zip_file_path = os.path.join(pack_folder, name)
                    nested_pack_folder = os.path.join(pack_folder, os.path.splitext(name)[0])
                    if not os.path.exists(nested_pack_folder):
                        os.makedirs(nested_pack_folder)
                    zip_ref.extract(name, pack_folder)
                    with zipfile.ZipFile(nested_zip_file_path, 'r') as nested_zip_ref:
                        nested_zip_ref.extractall(nested_pack_folder)
                    os.remove(nested_zip_file_path)  # Remove file zip after extraction

                    # Add the extracted package name and folder path to the list
                    extracted_pack_folders.append((os.path.splitext(name)[0], nested_pack_folder))
        
        # Remove downloaded zip file
        os.remove(zip_file_path)
        print("\rZip file extracted")

        return extracted_pack_folders
    
    except requests.exceptions.RequestException as e:
        print(f"\nFailed to download ZIP file: {e}")
        return None
    except zipfile.BadZipFile:
        print("The downloaded file is not a valid ZIP archive.")
        return None
    except Exception as e:
        print(f"\nAn error occurred: {e}")
        return None

if __name__ == "__main__":
    # Prompt the user for input
    custom_id = get_custom_id()

    if custom_id:
        Scraper.main(custom_id)

        # After Scraper.py completes, parse cache.json and extract the URL
        with open("cache.json", "r") as f:
            data = json.load(f)

        # Initialize lists to store the URLs for skin packs and other packs
        skin_urls = []
        other_urls = []

        for entry in data.values():
            for content in entry["Contents"]:
                if content.get("Type") == "skinbinary":
                    skin_urls.append(content["Url"])
                elif check_custom_id(custom_id):  # Check if custom ID is found before adding other URLs
                    other_urls.append(content["Url"])
                else:
                    print(colorama.Fore.RED + "Key not found for the DLC" + colorama.Style.RESET_ALL)

    # Prompt the user for input
    user_input = custom_id

    # Initialize a list to store folders that need to be removed after processing skin packs
    skin_folders_to_remove = []

    # Download and process each skin pack ZIP file
    for i, url in enumerate(skin_urls):
        # Append a sequential number to the folder name
        extracted_pack_folders = download_and_process_zip(url, user_input, "skin")
        renamed_folders = rename_extracted_folders(extracted_pack_folders, user_input, "skin")
        for pack_name, pack_folder in renamed_folders:
            skin.main(pack_folder)  # Call skin.py's main function
            skin_folders_to_remove.append(pack_folder)  # Add the folder to the list of folders to remove after processing

    # Remove the folders after processing all skin packs
    for folder in skin_folders_to_remove:
        remove_extracted_folder(folder)

    # Initialize a list to store folders that need to be removed
    folders_to_remove = []

    # Download and process each other pack ZIP file
    for i, url in enumerate(other_urls):
        # Append a sequential number to the folder name
        extracted_pack_folders = download_and_process_zip(url, user_input, "other")
        renamed_folders = rename_extracted_folders(extracted_pack_folders, user_input, "other")
        for pack_name, pack_folder in renamed_folders:
            dlc.main(pack_folder, "keys.tsv")  # Call dlc.py's main function
            folders_to_remove.append(pack_folder)  # Add the folder to the list of folders to remove

    # Remove the folders after processing all packs
    for folder in folders_to_remove:
        remove_extracted_folder(folder)