import subprocess

packages = ["pycryptodome==3.19.0", "colorama", "requests", "cryptography==3.3.2"]
subprocess.run(["pip", "install"] + packages, check=True)
