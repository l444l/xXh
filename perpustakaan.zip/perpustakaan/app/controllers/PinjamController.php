<?php
    require_once __DIR__.'/../models/Pinjam.php';
    class PinjamController {
        private $model;
        private $conn;
        public function __construct($conn) {
            $this->conn = $conn;
            $this->model = new Pinjam($conn);
        }

        public function viewList() {
            $data = $this->model->getAll()->fetch_all(MYSQLI_ASSOC);
            require_once __DIR__.'/../views/pinjam/list.php';
        }

        public function viewForm($id = null) {
            $pinjam = $id ? $this->model->getById($id) : null;

            require_once __DIR__.'/../models/Petugas.php';
            $petugasModel = new Petugas($this->conn);
            $petugass = $petugasModel->getAll()->fetch_all(MYSQLI_ASSOC);

            require_once __DIR__.'/../models/Buku.php';
            $bukuModel = new Buku($this->conn);
            $bukus = $bukuModel->getAll()->fetch_all(MYSQLI_ASSOC);

            require_once __DIR__.'/../models/Anggota.php';
            $anggotaModel = new Anggota($this->conn);
            $anggotas = $anggotaModel->getAll()->fetch_all(MYSQLI_ASSOC);

            require_once __DIR__.'/../views/pinjam/form.php';
        }



        public function store() {
            $this->model->create($_POST);
            header("Location: index.php?page=pinjam&action=list");
        }
        public function update($id) {
            $this->model->update($id, $_POST);
            header("Location: index.php?page=pinjam&action=list");
        }
        public function delete($id) {
            $this->model->delete($id);
            header("Location: index.php?page=pinjam&action=list");
        }
        // === API JSON ===
        public function api($method, $id = null) {
            header('Content-Type: application/json');
            switch ($method) {
            case 'GET':
            if ($id) {
                echo json_encode($this->model->getById($id));
            } else {
                $result = $this->model->getAll();
                $data = [];
                while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
                echo json_encode($data);
            }
            break;
            case 'POST':
                $input = json_decode(file_get_contents("php://input"), true);
                if ($this->model->create($input)) {
                    http_response_code(201);
                    echo json_encode(["message" => "Data berhasil ditambahkan"]);
                } else {
                    http_response_code(400);
                    echo json_encode(["error" => "Gagal menambah"]);
                }
            break;
            case 'PUT':
                $input = json_decode(file_get_contents("php://input"), true);
                if ($this->model->update($id, $input)) {
                echo json_encode(["message" => "Data berhasil diupdate"]);
                } else {
                http_response_code(400);
                echo json_encode(["error" => "Gagal update"]);
                }
            break;
            case 'DELETE':
                if ($this->model->delete($id)) {
                echo json_encode(["message" => "Data berhasil dihapus"]);
                } else {
                    http_response_code(400);
                    echo json_encode(["error" => "Gagal hapus"]);
                }
                break;
            }
        }
    }
?>
