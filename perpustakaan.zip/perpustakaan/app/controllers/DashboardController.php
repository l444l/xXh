<?php

class DashboardController {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function viewList() {
        require_once __DIR__.'/../views/dashboard.php';
    }
}