<?php
    require_once __DIR__.'/../models/Buku.php';
    class BukuController {
        private $model;
        public function __construct($conn) {
            $this->model = new Buku($conn);
        }
        public function viewList() {
            $data = $this->model->getAll();
            require_once __DIR__.'/../views/buku/list.php';
        }
        public function viewForm($id = null) {
            $buku = $id ? $this->model->getById($id) : null;
            require_once __DIR__.'/../views/buku/form.php';
        }
        public function store() {
            $this->model->create($_POST);
            header("Location: index.php?page=buku&action=list");
        }
        public function update($id) {
            // minimal guard: if no id provided, don't attempt update
            if (!$id) {
                header("Location: index.php?page=buku&action=list");
                return;
            }
            $this->model->update($id, $_POST);
            header("Location: index.php?page=buku&action=list");
        }
        public function delete($id) {
            $this->model->delete($id);
            header("Location: index.php?page=buku&action=list");
        }
        // === API JSON ===
        public function api($method, $id = null) {
            header('Content-Type: application/json');
            switch ($method) {
            case 'GET':
            if ($id) {
                echo json_encode($this->model->getById($id));
            } else {
                $result = $this->model->getAll();
                $data = [];
                while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
                echo json_encode($data);
            }
            break;
            case 'POST':
                $input = json_decode(file_get_contents("php://input"), true);
                if ($this->model->create($input)) {
                    http_response_code(201);
                    echo json_encode(["message" => "Data berhasil ditambahkan"]);
                } else {
                    http_response_code(400);
                    echo json_encode(["error" => "Gagal menambah"]);
                }
            break;
            case 'PUT':
                $input = json_decode(file_get_contents("php://input"), true);
                if ($this->model->update($id, $input)) {
                echo json_encode(["message" => "Data berhasil diupdate"]);
                } else {
                http_response_code(400);
                echo json_encode(["error" => "Gagal update"]);
                }
            break;
            case 'DELETE':
                if ($this->model->delete($id)) {
                echo json_encode(["message" => "Data berhasil dihapus"]);
                } else {
                    http_response_code(400);
                    echo json_encode(["error" => "Gagal hapus"]);
                }
                break;
            }
        }
    }
?> 
