<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Modern</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        @font-face {
            font-family: 'Hallowed Grounds';
            src: url('fonts/HallowedGrounds.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
        }

        a {
            text-decoration: none;
        }
        
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-image: url('intro/img/valentin-petrov-m-mal-01.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
        }

        h1, .dashboard-title {
            font-family: 'Hallowed Grounds', 'Poppins', sans-serif;
        }

        .page-root {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 800ms ease, transform 800ms ease;
        }
        .page-root.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .dashboard-container {
            background: rgba(15, 23, 42, 0.4);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 40px;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 1000px;
            text-align: center;
        }

        .dashboard-title {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 30px;
            letter-spacing: 1px;
            color: #1a3a2a;
        }
        
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }

        .menu-item {
            background: rgba(15, 23, 42, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.4);
            border-radius: 15px;
            padding: 25px 20px;
            text-decoration: none;
            color: #3d3d3d;
            font-weight: 500;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s ease, background 0.3s ease, box-shadow 0.3s ease;
        }
        
        .menu-item:hover {
            transform: translateY(-8px);
            background: rgba(255, 255, 255, 0.50);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .menu-item i {
            font-size: 2.8rem;
            margin-bottom: 15px;
        }

        .fa-users { color: #2980b9; }
        .fa-user-tie { color: #27ae60; }
        .fa-book { color: #d35400; }
        .fa-handshake { color: #8e44ad; }
            .container {
                position: relative;
            }

            .container i {
                font-size: 3.2rem;
                color: rgba(255,255,255,0.95);
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                margin: 0;
                display: block;
            }

            .container p {
                position: absolute;
                bottom: 1.6rem;
                left: 50%;
                transform: translateX(-50%);
                margin: 0;
                color: hsla(0,0%,100%,0.9);
                font-size: 1.8rem;
            }

        @media (max-width: 600px) {
            .menu-grid {
                grid-template-columns: 1fr;
            }

            .dashboard-container {
                padding: 30px 20px;
            }

            .dashboard-title {
                font-size: 2rem;
            }
        }

    </style>
    <link rel="stylesheet" href="css/paralax.css">
</head>
<body>


    <div class="page-root" id="pageRoot">
        <h1>D A S H B O A R D</h1>
        <p>SMK N1 Sukoharjo Wonosobo</p>
        <main class="dashboard-container">
            <section class="main">
                <a class="wrap wrap--1" href="index.php?page=anggota&action=list">
                    <div class="container container--1">
                        <i class="fa fa-users" aria-hidden="true"></i>
                        <p>1<br>Anggota</p>
                    </div>
                </a>

                <a class="wrap wrap--2" href="index.php?page=petugas&action=list">
                    <div class="container container--2">
                        <i class="fa fa-user-tie" aria-hidden="true"></i>
                        <p>2<br>Petugas</p>
                    </div>
                </a>

                <a class="wrap wrap--3" href="index.php?page=buku&action=list">
                    <div class="container container--3">
                        <i class="fa fa-book" aria-hidden="true"></i>
                        <p>3<br>Buku</p>
                    </div>
                </a>
                <a class="wrap wrap--4" href="index.php?page=pinjam&action=list">
                    <div class="container container--4">
                        <i class="fa fa-handshake" aria-hidden="true"></i>
                        <p>4<br>Peminjaman</p>
                    </div>
                </a>
            </section>
        </main>
    </div>

    <script>
        (function(){
            var root = document.getElementById('pageRoot');
            if(!root) return;
            requestAnimationFrame(function(){
                requestAnimationFrame(function(){
                    root.classList.add('visible');
                });
            });
        })();
    </script>
    <script src="js/paralax.js"></script>
</body>
</html>