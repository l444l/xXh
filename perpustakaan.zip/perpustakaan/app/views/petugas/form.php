<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Tambah Petugas</title>

    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome untuk Ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <link rel="stylesheet" href="ink/style.css">

    <style>
        select.form-control option {
            color: black;
            background-color: white;
        }

        .main-content {
            flex: 1;
            padding: 2rem;
            overflow-y: auto;
            position: relative;
        }

        .bg-toggle-btn {
            position: absolute;
            top: 2rem;
            right: 2rem;
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.2rem;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.3s ease;
        }

        .bg-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1) rotate(15deg);
        }

        .form-container {
            max-width: 700px;
            margin: 0 auto;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 2.5rem 3rem;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        }

        .form-container h1 {
            text-align: center;
            margin-bottom: 2rem;
            font-weight: 600;
            color: #fff;
            letter-spacing: 0.5px;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #dcdcdc;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: #f0f0f0;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.15);
            border-color: #60a5fa;
            box-shadow: 0 0 0 3px rgba(52, 168, 83, 0.3);
        }

        /* --- Form controls styling --- */
        .form-group {
            margin-bottom: 16px;
        }

        .form-control {
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(255, 255, 255, 0.06);
            color: #E0E0E0;
            outline: none;
            transition: background-color 0.2s, color 0.2s;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(3, 105, 161, 0.12);
        }

        /* Ensure selected status is readable – use classes toggled by JS */
        .form-control.dipinjam {
            background-color: rgba(251, 191, 36, 0.18);
            color: #1a1a1af2;
            border-color: rgba(251, 191, 36, 0.28);
        }

        .form-control.dikembalikan {
            background-color: rgba(74, 222, 128, 0.18);
            color: #1a1a1a;
            border-color: rgba(74, 222, 128, 0.28);
        }

        select.form-control {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23dcdcdc' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 1em;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(90deg, #3b82f6, #3b82f6);
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 1rem;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            background: linear-gradient(90deg, #60a5fa, #60a5fa);
        }

        #notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #34a853;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-20px);
            transition: opacity 0.5s ease, transform 0.5s ease, visibility 0.5s;
        }

        #notification.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
    </style>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigasi -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fa-solid fa-book-open-reader"></i> Perpus Digital</h2>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php?page=anggota&action=list"><span class="icon"><i class="fa-solid fa-users"></i></span> Anggota</a></li>
                    <li><a href="index.php?page=petugas&action=list" class="active"><span class="icon"><i class="fa-solid fa-user-tie"></i></span> Petugas</a></li>
                    <li><a href="index.php?page=buku&action=list"><span class="icon"><i class="fa-solid fa-book"></i></span> Buku</a></li>
                    <li><a href="index.php?page=pinjam&action=list"><span class="icon"><i class="fa-solid fa-handshake"></i></span> Peminjaman</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Konten Utama -->
        <main class="main-content">

            <div class="form-container">
                <!-- Judul dinamis tergantung apakah ini form edit atau tambah baru -->
                <h1><?= $petugas ? 'Edit Petugas' : 'Form Tambah Petugas' ?></h1>

                <form id="data-form" method="post" action="index.php?page=petugas&action=<?= $petugas ? 'update&id=' . $petugas['id_petugas'] : 'store' ?>">
                    <div class="form-group">
                        <label>Nama petugas:</label><br>
                        <input type="text" name="nama_petugas" value="<?= $petugas['nama_petugas'] ?? '' ?>" class="form-control"><br>
                    </div>

                    <div class="form-group">
                        <label>Username:</label><br>
                        <input type="text" name="username" value="<?= $petugas['username'] ?? '' ?>" class="form-control"><br>
                    </div>

                    <div class="form-group">
                        <label>Password:</label><br>
                        <input type="text" name="password" value="<?= $petugas['password'] ?? '' ?>" class="form-control"><br>
                    </div>

                    <button type="submit" class="submit-btn">Simpan Data</button>
                </form>
            </div>
        </main>
    </div>

    <!-- Elemen Notifikasi (Sama seperti sebelumnya) -->
    <div id="notification"></div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // --- PENAMBAHAN KODE UNTUK ANIMASI ON-LOAD ---
            // 1. Animasi untuk setiap baris data (Staggered Animation)
            const tableRows = document.querySelectorAll('.data-table tbody tr');
            tableRows.forEach((row, index) => {
                // Atur delay agar setiap baris muncul berurutan
                // Delay dimulai setelah animasi container tabel selesai (sekitar 700ms)
                const delay = 700 + (index * 100); // 100ms delay antar baris
                setTimeout(() => {
                    row.classList.add('visible');
                }, delay);
            });
            // --- AKHIR PENAMBAHAN ---


            // 2. Logika untuk tombol ganti background
            const toggleButton = document.getElementById('toggleBg');
            if (toggleButton) {
                toggleButton.addEventListener('click', function() {
                    if (document.querySelectorAll('.banner')) {
                        const banner = document.querySelector('div.banner2');
                        if (banner) {
                            banner.remove();
                        }
                        document.body.classList.toggle('banner');
                    } else {
                        const banner = document.querySelector('div.banner');
                        if (banner) {
                            banner.remove();
                        }
                        document.body.classList.toggle('banner2');
                    }
                });
            }

            // 3. Logika untuk animasi fade-out saat hapus data
            const deleteLinks = document.querySelectorAll('.delete-link');
            deleteLinks.forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    const userConfirmed = confirm('Apakah Anda yakin ingin menghapus data ini?');

                    if (userConfirmed) {
                        const row = this.closest('tr');
                        const href = this.getAttribute('href');
                        row.classList.add('fading-out');
                        setTimeout(() => {
                            window.location.href = href;
                        }, 500);
                    }
                });
            });
        });
    </script>
</body>

</html>