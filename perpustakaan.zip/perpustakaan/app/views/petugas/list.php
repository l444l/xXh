<?php
// --- DATA DUMMY UNTUK CONTOH ---
// Anda tidak perlu menyalin bagian ini, gunakan data dari database Anda.
// Ini hanya agar halaman bisa tampil tanpa koneksi database.
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Peminjaman - Perpustakaan</title>

    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome untuk Ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        /* CSS Reset & Basic Styling */
        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-image: url('intro/img/valentin-petrov-m-mal-01.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #E0E0E0;
            transition: background-image 0.5s ease-in-out;
            min-height: 100vh;
            overflow-x: hidden;
            /* Mencegah scroll horizontal saat animasi */
        }

        body.alt-bg {
            background-image: url('ink/bg.jpg');
        }

        /* Ensure banner doesn't center content and dashboard spans full width
           so the sidebar sits flush to the left edge. This overrides
           the rules in ink/style.css when this view is loaded. */
        .banner {
            display: block; /* full width wrapper */
            width: 100%;
            padding: 0;
            margin: 0;
        }

        .banner2 {
            display: block; /* full width wrapper */
            width: 100%;
            padding: 0;
            margin: 0;
        }

        .dashboard-container {
            display: flex;
            width: 100%;
            max-width: 100%;
            margin: 0;
        }

        /* --- Keyframes untuk Animasi On-Load --- */
        @keyframes slideInFromLeft {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }

            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideInFromTop {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes slideInFromBottom {
            from {
                transform: translateY(50px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        /* --- Sidebar Navigation --- */
        .sidebar {
            width: 260px;
            height: 100vh;
            position: sticky;
            top: 0;
            background: rgba(15, 23, 42, 0.4);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            padding: 20px;
            display: flex;
            flex-direction: column;
            /* Terapkan animasi sidebar */
            animation: slideInFromLeft 0.7s ease-out forwards;
        }

        .sidebar-header h2 {
            font-weight: 600;
            font-size: 1.8rem;
            color: #FFF;
            margin-bottom: 40px;
            text-align: center;
        }

        .sidebar nav ul {
            list-style: none;
        }

        .sidebar nav li a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 20px;
            margin-bottom: 8px;
            text-decoration: none;
            color: #E0E0E0;
            border-radius: 8px;
            transition: background-color 0.3s, color 0.3s;
        }

        .sidebar nav li a .icon {
            width: 20px;
            text-align: center;
        }

        .sidebar nav li a:hover {
            background-color: rgba(3, 105, 161, 0.5);
            color: #FFF;
        }

        .sidebar nav li a.active {
            background-color: #0369a1;
            color: #FFF;
            font-weight: 500;
        }

        .sidebar-footer {
            margin-top: auto;
        }

        #toggleBg {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.1);
            color: #E0E0E0;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        #toggleBg:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        /* --- Main Content --- */
        .main-content {
            flex-grow: 1;
            padding: 30px;
        }

        .main-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .main-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #FFF;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.4);
            /* Terapkan animasi header */
            opacity: 0;
            /* Sembunyikan awal */
            animation: slideInFromTop 0.6s ease-out 0.2s forwards;
            /* delay 0.2s */
        }

        .btn-tambah {
            background: #0ea5e9;
            color: #FFF;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 500;
            transition: background-color 0.3s, transform 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            /* Terapkan animasi tombol */
            opacity: 0;
            /* Sembunyikan awal */
            animation: slideInFromTop 0.6s ease-out 0.4s forwards;
            /* delay 0.4s */
        }

        .btn-tambah:hover {
            background: #0284c7;
            transform: translateY(-2px);
        }

        /* --- Table Styling --- */
        .table-container {
            background: rgba(15, 23, 42, 0.4);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 20px;
            overflow-x: auto;
            /* Terapkan animasi tabel container */
            opacity: 0;
            /* Sembunyikan awal */
            animation: slideInFromBottom 0.7s ease-out 0.5s forwards;
            /* delay 0.5s */
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th,
        .data-table td {
            padding: 15px;
            text-align: left;
        }

        .data-table thead {
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .data-table th {
            font-weight: 600;
            color: #FFF;
        }

        .data-table tbody tr {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            /* --- CSS untuk staggered animation --- */
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.5s ease-out, transform 0.5s ease-out;
        }

        /* Kelas 'visible' akan ditambahkan oleh JS untuk memicu transisi */
        .data-table tbody tr.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .data-table tbody tr:last-child {
            border-bottom: none;
        }

        .data-table tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }

        /* Animasi fadeout saat hapus */
        .fading-out {
            opacity: 0;
            transition: opacity 0.5s ease-out;
        }

        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            text-align: center;
        }

        .status.dipetugas {
            background-color: rgba(251, 191, 36, 0.2);
            color: #fbbf24;
        }

        .status.dikembalikan {
            background-color: rgba(74, 222, 128, 0.2);
            color: #4ade80;
        }

        .action-links a {
            text-decoration: none;
            margin-right: 15px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .action-links .edit-link {
            color: #60a5fa;
        }

        .action-links .edit-link:hover {
            color: #3b82f6;
        }

        .action-links .delete-link {
            color: #f87171;
        }

        .action-links .delete-link:hover {
            color: #ef4444;
        }
    </style>
    <link rel="stylesheet" href="ink/style.css">
</head>

<body>
        <div class="dashboard-container">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <h2><i class="fa-solid fa-book-open-reader"></i> Perpus Digital</h2>
                </div>
                <nav>
                    <ul>
                        <li><a href="index.php?page=anggota&action=list"><span class="icon"><i class="fa-solid fa-users"></i></span> Anggota</a></li>
                        <li><a href="index.php?page=petugas&action=list" class="active"><span class="icon"><i class="fa-solid fa-user-tie"></i></span> Petugas</a></li>
                        <li><a href="index.php?page=buku&action=list"><span class="icon"><i class="fa-solid fa-book"></i></span> Buku</a></li>
                        <li><a href="index.php?page=pinjam&action=list"><span class="icon"><i class="fa-solid fa-handshake"></i></span> Peminjaman</a></li>
                    </ul>
                </nav>
            <div class="sidebar-footer">
                <button id="toggleBg" class="bg-toggle-btn" title="Ganti Latar Belakang">
                    <i class="fa-solid fa-image"></i>
                </button>
            </div>
            </aside>

            <main class="main-content">
                <header class="main-header">
                    <h1>Daftar Petugas</h1>
                    <a href="index.php?page=petugas&action=form" class="btn-tambah">
                        <i class="fa-solid fa-plus"></i> Tambah Petugas
                    </a>
                </header>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Petugas</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; foreach ($data as $petugas): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($petugas['nama_petugas']) ?></td>
                                    <td><?= htmlspecialchars($petugas['username']) ?></td>
                                    <td><?= htmlspecialchars($petugas['password']) ?></td>
                                    <td class="action-links">
                                        <a class="edit-link" href="index.php?page=petugas&action=form&id=<?= $petugas['id_petugas'] ?>">Edit</a>
                                        <a class="delete-link" href="index.php?page=petugas&action=delete&id=<?= $petugas['id_petugas'] ?>">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // --- PENAMBAHAN KODE UNTUK ANIMASI ON-LOAD ---
            // 1. Animasi untuk setiap baris data (Staggered Animation)
            const tableRows = document.querySelectorAll('.data-table tbody tr');
            tableRows.forEach((row, index) => {
                // Atur delay agar setiap baris muncul berurutan
                // Delay dimulai setelah animasi container tabel selesai (sekitar 700ms)
                const delay = 700 + (index * 100); // 100ms delay antar baris
                setTimeout(() => {
                    row.classList.add('visible');
                }, delay);
            });
            // --- AKHIR PENAMBAHAN ---


            // 2. Logika untuk tombol ganti background
            const toggleButton = document.getElementById('toggleBg');
            if (toggleButton) {
                toggleButton.addEventListener('click', function() {
                    if (document.querySelectorAll('.banner')) {
                        const banner = document.querySelector('div.banner2');
                        if (banner) {
                            banner.remove();
                        }
                        document.body.classList.toggle('banner');
                    } else {
                        const banner = document.querySelector('div.banner');
                        if (banner) {
                            banner.remove();
                        }
                        document.body.classList.toggle('banner2');
                    }
                });
            }

            // 3. Logika untuk animasi fade-out saat hapus data
            const deleteLinks = document.querySelectorAll('.delete-link');
            deleteLinks.forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    const userConfirmed = confirm('Apakah Anda yakin ingin menghapus data ini?');

                    if (userConfirmed) {
                        const row = this.closest('tr');
                        const href = this.getAttribute('href');
                        row.classList.add('fading-out');
                        setTimeout(() => {
                            window.location.href = href;
                        }, 500);
                    }
                });
            });
        });
    </script>

</body>

</html>