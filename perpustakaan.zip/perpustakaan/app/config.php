<?php
    $conn = new mysqli("127.0.0.1", "root", "", "db_perpustakaan");
    if (!$conn) {
        die("Koneksi gagal: " . $conn->connect_error);
    }
?>