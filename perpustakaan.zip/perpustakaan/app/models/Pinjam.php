<?php
    class Pinjam {
        private $conn;
        public function __construct($db) {
            $this->conn = $db;
        }
        public function getAll() {
            return $this->conn->query(
                "SELECT
                p.*, pt.nama_petugas,
                a.nama_anggota, b.judul
                FROM peminjaman p
                JOIN petugas pt ON p.id_petugas = pt.id_petugas
                JOIN anggota a ON p.id_anggota = a.id_anggota
                JOIN buku b ON p.id_buku = b.id_buku"
            );
        }
        public function getById($id_peminjaman) {
            $stmt = $this->conn->prepare("SELECT * FROM peminjaman WHERE id_peminjaman = ?");
            $stmt->bind_param("i", $id_peminjaman);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }

        public function create($data) {
            $stmt = $this->conn->prepare("INSERT INTO peminjaman (id_petugas, id_anggota, id_buku, tanggal_pinjam, tanggal_kembali, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iiisss", $data['id_petugas'], $data['id_anggota'], $data['id_buku'], $data['tanggal_pinjam'], $data['tanggal_kembali'], $data['status']);
            return $stmt->execute();    
        }

        public function update($id_pinjam, $data) {
            $stmt = $this->conn->prepare("UPDATE peminjaman SET id_petugas=?, id_anggota=?, id_buku=?, tanggal_pinjam=?, tanggal_kembali=?, status=? WHERE id_peminjaman=?");
            $stmt->bind_param("iiisssi", $data['id_petugas'], $data['id_anggota'], $data['id_buku'], $data['tanggal_pinjam'], $data['tanggal_kembali'], $data['status'], $id_pinjam);
            return $stmt->execute();
        }

        public function delete($id_peminjaman) {
            $stmt = $this->conn->prepare("DELETE FROM peminjaman WHERE id_peminjaman=?");
            $stmt->bind_param("i", $id_peminjaman);
            return $stmt->execute();
        }
    }
?>
