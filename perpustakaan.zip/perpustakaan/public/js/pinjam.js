(function(){
    var btn = document.getElementById('bgToggle');
    if(!btn) return;

    function applyBgState(enabled){
        if(enabled) document.body.classList.add('bg-ink');
        else document.body.classList.remove('bg-ink');
    }

    // restore persisted state (localStorage fallback while we confirm session)
    try {
        var saved = localStorage.getItem('perpus_bg_ink');
        if(saved === '1') applyBgState(true);
    } catch(e){ /* ignore */ }

    btn.addEventListener('click', function(){
        // Add transition overlay to play ink animation then apply background class
        var overlay = document.createElement('div');
        overlay.className = 'ink-overlay';
        document.body.appendChild(overlay);

        setTimeout(function(){
            var enabled = !document.body.classList.contains('bg-ink');
            applyBgState(enabled);
            // persist on server via AJAX; on failure fallback to localStorage
            try {
                fetch('app/set_bg.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'enabled=' + (enabled ? '1' : '0')
                }).then(function(resp){
                    if(!resp.ok) throw new Error('Network error');
                    return resp.json();
                }).then(function(json){
                    try { localStorage.setItem('perpus_bg_ink', json.state == 1 ? '1' : '0'); } catch(e){}
                }).catch(function(){
                    try { localStorage.setItem('perpus_bg_ink', enabled ? '1' : '0'); } catch(e){}
                });
            } catch(e){ try { localStorage.setItem('perpus_bg_ink', enabled ? '1' : '0'); } catch(e){} }
            // remove overlay after animation
            setTimeout(function(){ if(overlay.parentNode) overlay.parentNode.removeChild(overlay); }, 900);
        }, 300);
    });
})();
