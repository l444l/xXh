<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/paralax.css">
</head>

<body>
  <h1>Parallax Tilt Effect Cards</h1>
  <p>Hover over the cards.</p>

  <section class="main">

    <div class="wrap wrap--1">
      <div class="container container--1">
        <p>01. Normal</p>
      </div>
    </div>

    <div class="wrap wrap--2">
      <div class="container container--2">
        <p>02. Reverse</p>
      </div>
    </div>

    <div class="wrap wrap--3">
      <div class="container container--3">
        <p>03. Normal</p>
      </div>
    </div>

  </section>
  <script src="js/paralax.js"></script>
</body>

</html>