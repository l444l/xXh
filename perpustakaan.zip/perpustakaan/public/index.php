<?php
// Enable sessions for site-wide settings (e.g., background preference)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__.'/../app/config.php';
require_once __DIR__.'/../app/controllers/PinjamController.php';
require_once __DIR__.'/../app/controllers/AnggotaController.php';
require_once __DIR__.'/../app/controllers/BukuController.php';
require_once __DIR__.'/../app/controllers/PetugasController.php';
require_once __DIR__.'/../app/controllers/DashboardController.php';

$page   = $_GET['page'] ?? 'intro';
$action = $_GET['action'] ?? 'list';
$id     = $_GET['id'] ?? null;

$controllers = [
    'anggota' => 'AnggotaController',
    'petugas' => 'PetugasController',
    'buku'    => 'BukuController',
    'pinjam'  => 'PinjamController',
    'dashboard'  => 'DashboardController'
];

if (!isset($controllers[$page])) {
    require_once __DIR__.'/../app/views/intro.php';
    exit;
}

$controllerName = $controllers[$page];
$controller = new $controllerName($conn);

$actions = [
    'list'   => 'viewList',
    'form'   => 'viewForm',
    'store'  => 'store',
    'update' => 'update',
    'delete' => 'delete'
];

if (isset($actions[$action])) {
    if (in_array($action, ['update', 'delete', 'form'])) {
        $controller->{$actions[$action]}($id);
    } else {
        $controller->{$actions[$action]}();
    }
} else {
    die("Aksi tidak valid!");
}
?>
